package trung.example.showproduct.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import trung.example.showproduct.service.ProductService;

@Controller
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/products")
    public String listProducts(Model model) {
        // Lấy danh sách từ Service
        model.addAttribute("products", productService.getAllProducts());
        // Trả về file HTML tên là "product-list"
        return "product-list";
    }
}